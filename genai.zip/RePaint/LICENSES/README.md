# License and Acknowledgement

A big thanks to following contributes that open sourced their code and therefore helped us a lot in developing RePaint!

This repository was forked from:
https://github.com/openai/guided-diffusion

It contains code from:
https://github.com/hojonathanho/diffusion

If we missed a contribution, please contact us.