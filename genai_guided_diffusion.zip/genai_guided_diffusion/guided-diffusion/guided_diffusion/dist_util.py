"""
Helpers for distributed training.
"""

"""
Helpers for distributed training.
"""

import io
import os
import socket
#import torch_directml

import blobfile as bf

# ── Try to import MPI; if anything goes wrong, fall back to a dummy COMM_WORLD ──
try:
    from mpi4py import MPI
except Exception:
    class _DummyComm:
        def Get_size(self):
            return 1

        def Get_rank(self):
            return 0
        def bcast(self, val, root=0):
            # single‐process fallback: just return the value
            return val

    class MPI:
        COMM_WORLD = _DummyComm()

import torch as th
import torch.distributed as dist


# Change this to reflect your cluster layout:
GPUS_PER_NODE = 8
SETUP_RETRY_COUNT = 3


def setup_dist():
    """
    Setup a torch.distributed process group.
    Falls back to single-process mode if MPI isn't available.
    """
    if dist.is_initialized():
        return

    rank = MPI.COMM_WORLD.Get_rank()
    world_size = MPI.COMM_WORLD.Get_size()

    # SINGLE-PROCESS FALLBACK: create a file-backed group so default PG exists
    if world_size == 1:
        # use a temporary file in the current workspace
        sync_file = os.path.abspath(os.path.join(os.getcwd(), "dist_init_sync"))
        # ensure it exists
        open(sync_file, "a").close()
        dist.init_process_group(
            backend="gloo",
            init_method=f"file://{sync_file}",
            world_size=1,
            rank=0,
        )
        print(f">>> Single-process file-based group initialized (rank=0, world_size=1)")
        return

    # Pin each rank to one GPU
    os.environ["CUDA_VISIBLE_DEVICES"] = str(rank % GPUS_PER_NODE)

    backend = "nccl" if th.cuda.is_available() else "gloo"

    # Determine master address
    master_addr = "localhost" if backend == "gloo" else socket.gethostbyname(socket.getfqdn())
    port = _find_free_port()

    # Broadcast master_addr and port so all ranks sync up via environment variables
    os.environ.update({
        "MASTER_ADDR": comm_bcast(master_addr),
        "MASTER_PORT": str(comm_bcast(port)),
        "RANK": str(rank),
        "WORLD_SIZE": str(world_size),
    })

    dist.init_process_group(backend=backend, init_method="env://")


def comm_bcast(val, root=0):
    """
    Broadcast a Python object across MPI ranks.
    """
    return MPI.COMM_WORLD.bcast(val, root=root)


def dev():
    """
    Return the DirectML device (for AMD on Windows) if available,
    otherwise CUDA if available, else CPU.
    """

    # Fallback to CUDA or CPU
    return th.device("cuda" if th.cuda.is_available() else "cpu")



def load_state_dict(path, **kwargs):
    """
    Load a PyTorch checkpoint via blobfile, reading only on rank 0
    and broadcasting the raw bytes to the others.
    """
    chunk_size = 2 ** 30
    rank = MPI.COMM_WORLD.Get_rank()

    if rank == 0:
        with bf.BlobFile(path, "rb") as f:
            data = f.read()
        num_chunks = (len(data) + chunk_size - 1) // chunk_size
        MPI.COMM_WORLD.bcast(num_chunks)
        for i in range(num_chunks):
            MPI.COMM_WORLD.bcast(data[i * chunk_size:(i + 1) * chunk_size])
    else:
        num_chunks = MPI.COMM_WORLD.bcast(None)
        chunks = [MPI.COMM_WORLD.bcast(None) for _ in range(num_chunks)]
        data = b"".join(chunks)

    return th.load(io.BytesIO(data), **kwargs)


def sync_params(params):
    """
    Broadcast model parameters from rank 0 to all other ranks.
    """
    try:
        world_size = dist.get_world_size()
    except Exception:
        world_size = 1

    if world_size <= 1:
        # nothing to sync
        return

    for p in params:
        with th.no_grad():
            dist.broadcast(p, src=0)


def _find_free_port():
    """
    Find an available TCP port on localhost.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("", 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]
    finally:
        s.close()
